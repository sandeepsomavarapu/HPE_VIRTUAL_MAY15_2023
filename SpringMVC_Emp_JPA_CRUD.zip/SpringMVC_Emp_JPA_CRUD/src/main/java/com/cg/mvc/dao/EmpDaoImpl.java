package com.cg.mvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.mvc.dto.Emp;


@Repository("empDao")
public class EmpDaoImpl implements EmpDao {
	@PersistenceContext
	EntityManager manager;

	@Override
	public Emp save(Emp emp) {
		manager.persist(emp);
		return emp;
	}
	@Override
	public Emp update(Emp emp) {
		Emp e1 = getEmpById(emp.getId());
		if (e1 != null) {
			manager.merge(emp);
		}else {
			manager.persist(emp);
		}
		return emp;
	}
	@Override
	public void delete(int id) {
		Emp e1 = getEmpById(id);
		if (e1 != null)
			manager.remove(e1);

	}
	@Override
	public Emp getEmpById(int id) {
		return manager.find(Emp.class, id);
	}
	@Override
	public List<Emp> getEmployees() {
		Query query = manager.createQuery("FROM Emp");//select e from Emp e
		return query.getResultList();
	}
}