package com.cg.mvc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.mvc.dto.Emp;
import com.cg.mvc.service.EmpService;     

@Controller    
public class EmpController {    
    @Autowired    
    EmpService service;//will inject service from XML file    
        
    /*It displays a form to input data, here "command" is a reserved request attribute  
     *which is used to display object data into form  
     */    
    @RequestMapping("/empform")    //get,post,put,delete
    public String showform(Model m){    
        m.addAttribute("command", new Emp());  
        return "empform";   
    }    
    /*It saves object into database. The @ModelAttribute puts request data  
     *  into model object. You need to mention RequestMethod.POST method   
     *  because default request is GET*/    
    @RequestMapping(value="/save",method = RequestMethod.POST)   //@PostMapping 
    public String save(@ModelAttribute("emp") Emp emp){    
        service.save(emp);    
        return "redirect:/viewemp";//will redirect to viewemp request mapping    
    }    
    /* It provides list of employees in model object */    
    @RequestMapping("/viewemp")    
    public String viewemp(Model m){    
        List<Emp> list=service.getEmployees();    
        m.addAttribute("list",list);  
        return "viewemp";    
    }    
    /* It displays object data into form for the given id.   
     * The @PathVariable puts URL data into variable.*/    
    @RequestMapping(value="/editemp/{id}")    
    public String edit(@PathVariable("id") int id, Model m){ 
    	System.out.println("empid for update"+id);
        Emp emp=service.getEmpById(id);  
        System.out.println(emp+"emp data ");
        m.addAttribute("command",emp);  
        return "redirect:/editempform";    
    }    
    /* It updates model object. */    
    @RequestMapping(value="/editsave")    
    public String editsave(@ModelAttribute("emp") Emp emp){    
        service.update(emp);    
        return "redirect:/viewemp";    
    }    
    /* It deletes record for the given id in URL and redirects to /viewemp */    
    @RequestMapping(value="/deleteemp/{id}")    
    public String delete(@PathVariable int id){    
        service.delete(id);    
        return "redirect:/viewemp";    
    }     
} 