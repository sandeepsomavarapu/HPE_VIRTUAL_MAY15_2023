package com.hp.productapp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.hp.productapp.entity.Product;

@Repository
public class ProductDaoImpl implements ProductDao {
	@PersistenceContext
	EntityManager entityManager;// insert-->persist(),update-->merge(),delete-->remove(),select--->find(),records(JPQL)-->createQuery()

	@Override
	public String addProduct(Product product) {
		entityManager.persist(product);
		return "Product Inserted Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		entityManager.merge(product);
		return "Product Updated Successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		entityManager.remove(getProduct(productId));
		return "Product Deleted Successfully ";
	}

	@Override
	public Product getProduct(int productId) {

		return entityManager.find(Product.class, productId);
	}

	@Override
	public List<Product> GetAllProducts() {
		TypedQuery<Product> products = entityManager.createQuery("select p from Product p", Product.class);
		return products.getResultList();
	}

	@Override
	public List<Product> getAllProductsByPriceRange(int intialPrice, int finalPrice) {
		TypedQuery<Product> products = entityManager
				.createQuery("select p from Product p where p.productPrice between ?1 and ?2", Product.class);
		products.setParameter(1, intialPrice);
		products.setParameter(2, finalPrice);
		return products.getResultList();
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {
		TypedQuery<Product> products = entityManager.createQuery("select p from Product p where p.productCategory=?1", Product.class);
			products.setParameter(1,category);
		return products.getResultList();
	}

}
