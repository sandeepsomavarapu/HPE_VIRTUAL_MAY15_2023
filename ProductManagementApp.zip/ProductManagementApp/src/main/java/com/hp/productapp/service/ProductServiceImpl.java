package com.hp.productapp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hp.productapp.dao.ProductDao;
import com.hp.productapp.entity.Product;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDao dao;

	@Override
	public String addProduct(Product product) {

		return dao.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {

		return dao.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {

		return dao.deleteProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {

		return dao.getProduct(productId);
	}

	@Override
	public List<Product> GetAllProducts() {
		return dao.GetAllProducts();
	}

	@Override
	public List<Product> getAllProductsByPriceRange(int intialPrice, int finalPrice) {
		return dao.getAllProductsByPriceRange(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {
		return dao.getAllProductsByCategory(category);
	}

}
