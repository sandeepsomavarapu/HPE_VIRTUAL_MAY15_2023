package com.hpe.jdbccrud;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class EmployeeClient {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("mysql");
		// insert-->persist(),update-->merge(),select-->find(),delete-->remove()
		// EntityManager
		EntityManager em = factory.createEntityManager();
		//Employee emp = new Employee(111, "suresh", 43000, "banglore");
		em.getTransaction().begin();
		//em.persist(emp);// ORM
		
		Employee emp=em.find(Employee.class,111);
		
		System.out.println(emp);
		
		em.remove(emp);
		
//		emp.setEmpSal(52000);
//		emp.setEmpAddress("hyderabad");
//		
//		em.merge(emp);
		
		em.getTransaction().commit();
	}

}
