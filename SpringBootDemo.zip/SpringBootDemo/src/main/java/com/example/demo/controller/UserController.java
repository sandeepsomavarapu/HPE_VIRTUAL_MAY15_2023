package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;

@RestController
@RequestMapping("/HPE")
public class UserController {

	@RequestMapping("/welcome") // http://localhost:1122/HPE/welcome
	public String sayHello() {
		return "Hello Everyone Good Evening!!! ";
	}

	@RequestMapping("/getemps") // http://localhost:1122/HPE/getemps
	public List<Employee> getEmployees() {
		ArrayList<Employee> emps = new ArrayList<Employee>();
		emps.add(new Employee(123, "sandeep", 9000, "trainer"));
		emps.add(new Employee(456, "naresh", 4569, "developer"));
		emps.add(new Employee(89, "satish", 89000, "manager"));
		emps.add(new Employee(2321, "sathya", 78945, "intern"));

		return emps;
	}

}
